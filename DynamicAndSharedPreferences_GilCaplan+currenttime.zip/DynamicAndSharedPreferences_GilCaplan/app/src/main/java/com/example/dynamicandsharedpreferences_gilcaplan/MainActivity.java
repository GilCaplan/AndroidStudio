package com.example.dynamicandsharedpreferences_gilcaplan;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.text.SimpleDateFormat;
import java.util.Date;
public class MainActivity extends AppCompatActivity {
    LinearLayout mainLayout,l1,l2,l3,settingsLayout, loginLayout;
    Button setting,login,RandomImage,save,bckgrnd;
    Dialog dialog_setting, dialog_login;
    ImageView iv1,iv2,iv3,iv4,iv5,iv6,IV;
    List<ImageView> iv;
    TextView tv,share;
    EditText ET1,ET2;
    SharedPreferences myPrefs;
    String name, password;
    int num;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mainLayout= new LinearLayout(this);
        mainLayout= findViewById(R.id.main);
        mainLayout.setOrientation(LinearLayout.VERTICAL);

        l2=new LinearLayout(this);
        l3=new LinearLayout(this);


        login= new Button(this);setting= new Button(this);
        login.setText("login");setting.setText("settings");
        login.setOnClickListener((v)->{ CreateLoginDialogue();});
        setting.setOnClickListener((v)->{CreateSettingDialogue();});
        l1= new LinearLayout(this);
        l1.setOrientation(l1.HORIZONTAL);
        l1.addView(setting);l1.addView(login);
        mainLayout.addView(l1);

        iv= new ArrayList<ImageView>();

        RandomImage= new Button(this);
        RandomImage.setText("Generate a random pic");
        RandomImage.setOnClickListener((v)->{num= (int) (6 * Math.random());IV.setImageDrawable(iv.get(num).getDrawable());});
        IV= new ImageView(this);
        IV.setImageResource(R.drawable.dog);
        l2.addView(IV);
        mainLayout.addView(l2);
        mainLayout.addView(RandomImage);


        iv1= new ImageView(this);
        iv1.setImageResource(R.drawable.dog);iv.add(iv1);

        iv2= new ImageView(this);
        iv2.setImageResource(R.drawable.hippo);iv.add(iv2);

        iv3= new ImageView(this);
        iv3.setImageResource(R.drawable.horse);iv.add(iv3);

        iv4= new ImageView(this);
        iv4.setImageResource(R.drawable.human);iv.add(iv4);

        iv5= new ImageView(this);
        iv5.setImageResource(R.drawable.lion);iv.add(iv5);

        iv6= new ImageView(this);
        iv6.setImageResource(R.drawable.rhino);iv.add(iv6);

        bckgrnd= new Button(this);
        bckgrnd.setOnClickListener((v)->{Random rnd = new Random();int color = Color.argb(255, rnd.nextInt(256), rnd.nextInt(256), rnd.nextInt(256));mainLayout.setBackgroundColor(color);});
    //random color
        bckgrnd.setText("Background color");
        l3.setOrientation(l3.HORIZONTAL);
        l3.addView(bckgrnd);
        save= new Button(this);

        myPrefs= getSharedPreferences("myPrefs", MODE_PRIVATE);

        save.setText("Save and Exit");
        save.setOnClickListener((v)->{
            name= ET1.getText().toString();
            password=ET2.getText().toString();
            SharedPreferences.Editor prefsEditor;
            prefsEditor = myPrefs.edit();
            prefsEditor.putString("username", !name.equals(null)?name:"");
            prefsEditor.putString("password", !password.equals(null)? password:"");
            prefsEditor.commit();

            myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
            int pid = android.os.Process.myPid();android.os.Process.killProcess(pid);});//add save part
    l3.addView(save);
    mainLayout.addView(l3);
    }
    public void getshared(EditText ET1,EditText ET2, SharedPreferences myPrefs){
        String name= ET1.getText().toString();
        String password=ET2.getText().toString();
        SharedPreferences.Editor prefsEditor;
        prefsEditor = myPrefs.edit();
        prefsEditor.putString("username", !name.equals(null)?name:"");
        prefsEditor.putString("password", !password.equals(null)? password:"");
        prefsEditor.commit();

        myPrefs = getSharedPreferences("myPrefs", MODE_PRIVATE);
    }



    public void CreateSettingDialogue(){
        dialog_setting= new Dialog(this);

        dialog_setting.setContentView(R.layout.dialogue_settings);
        dialog_setting.show();
        tv= new TextView(this);
        String s= "settings is here:)";
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd 'at' HH:mm:ss z");
        Date date = new Date(System.currentTimeMillis());
        tv.setText(formatter.format(date));
        settingsLayout=findViewById(R.id.settings);
        settingsLayout= new LinearLayout(this);
        settingsLayout.addView(tv);
        dialog_setting.setContentView(settingsLayout);
    }
    public void CreateLoginDialogue(){
        dialog_login= new Dialog(this);

        dialog_login.setContentView(R.layout.dialogue_login);
        dialog_login.show();
        loginLayout=findViewById(R.id.login);
        loginLayout= new LinearLayout(this);
        TextView t1,t2;
        LinearLayout l1,l2;
        loginLayout.setOrientation(loginLayout.VERTICAL);
        l1= new LinearLayout(this);
        l2= new LinearLayout(this);
        l1.setOrientation(l1.HORIZONTAL);
        l2.setOrientation(l2.HORIZONTAL);
        t1= new TextView(this);
        t2= new TextView(this);
        t1.setText("Enter name:   ");
        t2.setText("Enter a password:  ");
        ET1= new EditText(this);
        ET2= new EditText(this);
        l1.addView(t1);l1.addView(ET1);
        l2.addView(t2);l2.addView(ET2);

        loginLayout.addView(l1);
        loginLayout.addView(l2);
        ET1.setText(myPrefs.getString("username",""));
        ET2.setText(myPrefs.getString("password",""));
        name= ET1.getText().toString();
        password=ET2.getText().toString();

        dialog_login.setContentView(loginLayout);

    }
}