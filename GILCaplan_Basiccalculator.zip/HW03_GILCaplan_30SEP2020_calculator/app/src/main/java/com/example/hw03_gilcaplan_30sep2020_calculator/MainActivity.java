package com.example.hw03_gilcaplan_30sep2020_calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.nio.file.attribute.AclEntryType;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private  int counter1=0,counter2=0,counter=0,plus,division,mult,subt;
    private Button buttonPlus, buttonMinus,buttonMul, buttondivision, buttoncalc,buttonReset;
    private EditText ETnum1,ETnum2,ETAns;
    private String TAG = "gilog";
    private LinearLayout bb;
    boolean Addition, Subtract, Multiplication, Division;
    private int value;
    private TextView tvanswer;
    private LinearLayout me;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        me= (LinearLayout) findViewById(R.id.bb);

        me.setBackgroundColor(Color.parseColor("#8B0000"));



        buttonPlus = findViewById(R.id.buttonPlus);
        Log.d(TAG, "onCreate: buttonplus");
        buttonMinus =  findViewById(R.id.buttonMinus);
        Log.d(TAG, "onCreate: button minus");
        buttondivision= findViewById(R.id.buttondivision);
        buttonMul= findViewById(R.id.buttonMul);
        ETnum1 = findViewById(R.id.ETnum1);
        ETnum2= findViewById(R.id.ETnum2);
        Log.d(TAG, "onCreate: et counter");
        buttoncalc= (Button)findViewById(R.id.buttoncalc);
        buttonReset= (Button)findViewById(R.id.buttonReset);
        tvanswer= findViewById(R.id.tvanswer);


        buttonPlus.setOnClickListener(this);
        Log.d(TAG, "onCreate: click button listener+");
        buttonMinus.setOnClickListener(this);
        Log.d(TAG, "onCreate: listner button--");
        buttondivision.setOnClickListener(this);
        buttonMul.setOnClickListener(this);
        buttonReset.setOnClickListener(this);
        buttoncalc.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

        String value1= ETnum1.getText().toString();
        counter1=Integer.parseInt(value1);
        Log.d(TAG, "onClick: we have counter num1");
        String value2= ETnum2.getText().toString();
        counter2=Integer.parseInt(value2);
        Log.d(TAG, "onClick: we have counter num2");

        if (R.id.buttonPlus == v.getId()){
                counter = Integer.parseInt( counter1 + counter2 + "");
                Addition = true;
                Log.d(TAG, "onClick: buttonplus works");
        }
        if (R.id.buttonMinus == v.getId()){
                counter =  Integer.parseInt( counter1 - counter2 + "");
                Subtract = true;
                Log.d(TAG, "onClick: button minus works");
        }
        if (R.id.buttondivision == v.getId()){
                counter =  Integer.parseInt( counter1 / counter2 + "");
                Division = true;
                Log.d(TAG, "onClick: button division works");
                Toast.makeText(this,  ETnum2.getText(), Toast.LENGTH_SHORT).show();
        }
        if (R.id.buttonMul == v.getId()){
                counter =  Integer.parseInt( counter1 * counter2 + "");
                Multiplication = true;
                Log.d(TAG, "onClick: button times works");
        }
        if (R.id.buttonReset == v.getId()){//the reset isn't needed just there incase.
            tvanswer.setText("" + 0);
            ETnum2.setText("" + 0);
            ETnum1.setText("" + 0);
            counter1=0;
            counter2=0;
            counter=0;
            Addition= false;
            Multiplication= false;
            Division=false;
            Subtract=false;
            Log.d(TAG, "onClick: reset?");
        }
        if (R.id.buttoncalc == v.getId()){
            Log.d(TAG, "onClick: calculator button pressed");
            if (Addition == true)
                tvanswer.setText(""+ counter);
                 Addition = false;
        }
             if (Subtract == true){
                 tvanswer.setText(""+ counter);
                 Subtract= false;
             }
             if (Division == true){
                     tvanswer.setText(""+ counter);
                     Division = false;
        }
             if(Multiplication == true){
                     tvanswer.setText(""+ counter);
                     Multiplication= false;
        }

    }
}