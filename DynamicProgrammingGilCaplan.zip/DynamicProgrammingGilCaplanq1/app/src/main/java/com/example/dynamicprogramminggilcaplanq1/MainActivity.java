package com.example.dynamicprogramminggilcaplanq1;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static TextView TVSTARS ;
    LinearLayout Mainlayout,scrollView;
    private ImageView iv;
    private EditText ET;
    LinearLayout l2;
    RadioGroup radioGroup;
    RadioButton ver,hor;
    List<Button> l;
    ScrollView s;
    int cnt=0;
    HorizontalScrollView horizontal;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Mainlayout= findViewById(R.id.main);
        Mainlayout.setBackgroundColor(Color.RED);
        Mainlayout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout l1= new LinearLayout(this);
        ET= new EditText(this);
        ET.setText("0");
        l1.addView(ET);
        TVSTARS= new TextView(this);
        Mainlayout.addView(TVSTARS);
        Button button= new Button(this);
        button.setText("generate buttons");
        l1.addView(button);
        radioGroup= new RadioGroup(this);
        ver= new RadioButton(this);
        ver.setText("vertical");
        hor= new RadioButton(this);
        hor.setText("horizontal");
        radioGroup.addView(ver);
        radioGroup.addView(hor);
        radioGroup.setOrientation(radioGroup.HORIZONTAL);
        Mainlayout.addView(radioGroup);
        ver.setChecked(true);
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {

                if(ver.isChecked() &&scrollView!=null) {
                    horizontal.removeView(scrollView);
                    scrollView.setOrientation(scrollView.VERTICAL);
                    s.addView(scrollView);
                    s.setVisibility(s.VISIBLE);
                }
                if(hor.isChecked() && scrollView!=null){
                    s.removeView(scrollView);
                    scrollView.setOrientation(scrollView.HORIZONTAL);
                    horizontal.addView(scrollView);
                    horizontal.setVisibility(s.VISIBLE);
                    Mainlayout.addView(horizontal);

                }
            }
        });
        button.setOnClickListener((v)-> {//generate button
            if (s!=null) {
                s.setVisibility(s.GONE);
            }
            scrollView= new LinearLayout(this);
            String num = ET.getText().toString();
            int n = num.matches("^[0-9]+$") ?  Integer.valueOf(num): 0;
            buttons(n);
        });


        iv= new ImageView(this);
        iv.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT,1.0f));
        iv.setImageResource(R.drawable.iv);
        l1.addView(iv);
        Mainlayout.addView(l1);
    }
    public void buttons(int n){
        LinearLayout.LayoutParams params= new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        ver.setChecked(true);
        for(int i=1;i<=n;i++) {
            final int s = i;
            Button b = new Button(this);
            b.setLayoutParams(params);
            params.setMargins(0, 0, 0, 0);
            b.setText(String.valueOf(i));
            b.setOnClickListener((v) -> {
                String stars = "";
                Toast.makeText(this, "tis is dynamic:)", Toast.LENGTH_SHORT).show();
                for (int j = 0; j < s; j++) {
                    stars += "*";
                }
                TVSTARS.setText(stars);
            });
           scrollView.addView(b);
        }
        s=new ScrollView(this);
        horizontal=new HorizontalScrollView (this);
        scrollView.setLayoutParams(params);
        s.setLayoutParams(params);
        if(scrollView!=null) {
            scrollView.setOrientation(scrollView.VERTICAL);
            s.addView(scrollView);
            Mainlayout.addView(s);
        }
    }
}
